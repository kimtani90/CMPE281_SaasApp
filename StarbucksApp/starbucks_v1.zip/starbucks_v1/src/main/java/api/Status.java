package api ;

class Status {

    public String status ;
    public String message ;

}