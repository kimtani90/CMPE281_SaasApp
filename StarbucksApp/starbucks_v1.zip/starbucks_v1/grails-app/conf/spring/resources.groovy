beans = {
    corsFilter(main.java.api.CorsFilter)
}