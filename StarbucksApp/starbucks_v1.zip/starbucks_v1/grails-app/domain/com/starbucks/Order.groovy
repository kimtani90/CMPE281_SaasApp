package com.starbucks

class Order {

    static constraints = {
    }

    String qty
    String name
    String milk
    String size
}
